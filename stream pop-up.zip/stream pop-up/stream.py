from subprocess import call

call(["node", "program/index.js"])