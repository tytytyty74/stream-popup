function addHandler(ele,trigger,handler){
    ele.addEventListener(trigger,handler,false);
}

function onStoargeEvent(e) {
    var value = localStorage.getItem('key');
    console.log('Successfully communicate with other tab');
    console.log('Received data: ' + value);
    document.getElementById('value').innerText = value;
}

addHandler(window,"storage",onStoargeEvent);