function popup()
{
    localStorage.setItem('key', "hello world 2")
    alert("popup")
}
