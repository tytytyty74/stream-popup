var http = require('http');
var fs = require('fs');
var io = require('socket.io');

http.createServer(function(req, res){
    console.log(req.url.substring(1))
    if (req.url.includes(".gif")||req.url.includes(".png")||req.url.includes(".jpg")){
        img = fs.readFileSync(req.url.substring(1))
        res.writeHead(200, {'content-type':'image/gif'});
        res.end(img, 'binary')
    }
    else if (req.url.substring(1).includes(".ico")){}
    else
    {
        fs.readFile(req.url.substring(1), function(err, data){
            res.writeHead(200, {'Content-Type':'text/html'});
            res.write(data);
            res.end();
        });
    }
}).listen(8080);
fs.watchFile("popup.json", {interval:100}, function(curr, prev)
{
    fs.readFile("popup.json",{encoding:"utf8"}, function(err, data){
        var obj = JSON.parse(data)
        console.log(obj.text)
        //io.emit("popup", data)
    })
});