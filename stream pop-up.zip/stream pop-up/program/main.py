import Tkinter as tkinter
from tkColorChooser import askcolor
import tkMessageBox
import json
from decimal import Decimal
from  subprocess import Popen
def popup(page):
    try:
        float(page.button2.get())
        try:
            float(page.button3.get())
            try:
                float(page.button5.get())
                try:
                    if float(page.button4.get()) <= 1.0:
                        send(page.button1, page.color, page.button3, 
                             page.textColor, page.button4, page.button5,
                             page.button2, page.inFrom, page.outFrom)
                    else:
                        page.showwarning("opacity must be a number between 0 and 1")
                except ValueError:
                    page.showwarning("opacity must be a number between 0 and 1")
            except ValueError:
                page.showwarning("border radius must be a number")
        except ValueError:
            page.showwarning("duration must be a number")
    except ValueError:
        page.showwarning("text size mut be a number")
def send(entry1, entry2, entry3, entry4, entry5, entry6, entry7, entry8, entry9):
    f =open("assets/popup.json", "r+")
    jsonData = json.load(f)
    jsonData["text"] = entry1.get(1.0, tkinter.END)
    jsonData["textS"]=float(entry7.get())
    jsonData["color"] = entry2[1]
    jsonData["textColor"] = entry4[1]
    jsonData["duration"] = float(entry3.get())
    jsonData["opacity"] = float(entry5.get())
    jsonData["borderR"] = float(entry6.get())
    jsonData["in"] = entry8.get()
    jsonData["out"] = entry9.get()
    f.seek(0)
    f.write(json.dumps(jsonData))
    f.truncate()
    f.close()
class window:
    color = ((0, 0, 0), "#ff0000")
    textColor = ((0, 0, 0), "#000000")
    def __init__(self):
        self.root = tkinter.Tk()
        self.__makebuttons__()
        self.root.mainloop()
        
    def __makebuttons__(self):
        self.label1 = tkinter.Label(self.root, text="text to go into the popup").grid(row=0, column=0, sticky=tkinter.NW)
        
        self.button1 = tkinter.Text(self.root, width=25, height=2.5)
        self.button1.grid(row=0, column=1)
        
        self.label2 = tkinter.Label(self.root, text="text size(decimal number 1.0-10.0)").grid(row=1, column=0, sticky=tkinter.W)
        
        self.button2 = tkinter.Entry(self.root, width=25)
        self.button2.grid(row=1, column=1, sticky=tkinter.W)
        
        self.label3 = tkinter.Label(self.root, text="how long the popup will stay up").grid(row=2, column=0, sticky=tkinter.W)
        
        self.button3 = tkinter.Entry(self.root, width=25)
        self.button3.grid(row=2, column=1, sticky=tkinter.W)
        
        self.label4 = tkinter.Label(self.root, text="the opacity of the popup").grid(row=3, column=0, sticky=tkinter.W)
        
        self.button4 = tkinter.Entry(self.root, width=25)
        self.button4.grid(row=3, column=1, sticky=tkinter.W)
        
        self.label5 = tkinter.Label(self.root, text="how curved the popup corners are(border radius)").grid(row=4, column=0, sticky=tkinter.W)
        
        self.button5 = tkinter.Entry(self.root, width=25)
        self.button5.grid(row=4, column=1, sticky=tkinter.W)
        
        self.label6 = tkinter.Label(self.root, text="will come in from").grid(row=5, column=0, sticky=tkinter.W)
        
        self.inFrom = tkinter.StringVar()
        self.inFrom.set("left")
        self.button6 = tkinter.OptionMenu(self.root, self.inFrom, "left", "top", "bottom")
        self.button6.grid(row=5, column=1, sticky=tkinter.W)
        
        self.label6 = tkinter.Label(self.root, text="will leave from").grid(row=6, column=0, sticky=tkinter.W)
        
        self.outFrom = tkinter.StringVar()
        self.outFrom.set("left")
        self.button7 = tkinter.OptionMenu(self.root, self.outFrom, "left", "top", "bottom")
        self.button7.grid(row=6, column=1, sticky=tkinter.W)
        
        self.colorVar = tkinter.StringVar()
        self.colorVar.set("background color: "+self.color[1])
        self.button8 = tkinter.Button(self.root, textvariable=self.colorVar, command=self.__colorset__)
        self.button8.grid(row=7, column=0, sticky=tkinter.E)
        
        self.textColorVar = tkinter.StringVar()
        self.textColorVar.set("text color: "+self.textColor[1])
        self.button9 = tkinter.Button(self.root, textvariable=self.textColorVar, command=self.__textcolorset__)
        self.button9.grid(row=7, column=1, sticky=tkinter.W)
        
        self.button10 = tkinter.Button(self.root, text="go", width=10, command=lambda: popup(self))
        self.button10.grid(row=8, column=1, sticky=tkinter.E)
    def __colorset__(self):
        self.color=askcolor()
        self.colorVar.set("background color: "+self.color[1])
    def __textcolorset__(self):
        self.textColor=askcolor()
        self.textColorVar.set("text color: "+self.textColor[1])
        print self.textColor[1]
    def showwarning(self, mess):
        tkMessageBox.showerror("alert", mess)
Popen(["node", "index.js"], shell=True)
main = window()    

