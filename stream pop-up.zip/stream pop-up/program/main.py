import Tkinter as tkinter
from tkColorChooser import askcolor
import tkMessageBox
import json
from decimal import Decimal
from  subprocess import Popen
def reset():
    f=open("assets/default.json", "w")
    jsonData = {"opacity":"", "bg": "#ff0000", "ts":"", "in":"left", 
                "duration":"", "borderR":"", "tc":"#000000", "out":"left"}
    f.seek(0)
    f.write(json.dumps(jsonData))
    f.truncate()
    f.close()
def arIsPos(arr):
    x = True
    for i in arr:
        if i < 0:
            x=False
    return x        
    
def popup(page):
    try:
        float(page.ts.get())
        try:
            float(page.duration.get())
            try:
                float(page.borderR.get())
                try:
                    if float(page.opacity.get()) <= 1.0:
                        if arIsPos([float(page.ts.get()), 
                                    float(page.duration.get()), 
                                    float(page.borderR.get()),
                                    float(page.opacity.get())]):
                            send(page.button1, page.color, page.duration, 
                                 page.textColor, page.opacity, page.borderR,
                                 page.ts, page.inFrom, page.outFrom)
                        else:
                            
                            page.showwarning("all numbers must be positive")
                    else:
                        page.showwarning("opacity must be a number between 0 \
                        and 1")
                except ValueError:
                    page.showwarning("opacity must be a number between 0 and \
                    1")
            except ValueError:
                page.showwarning("border radius must be a number")
        except ValueError:
            page.showwarning("duration must be a number")
    except ValueError:
        page.showwarning("text size mut be a number")
def send(entry1,entry2,entry3,entry4,entry5,entry6,entry7,entry8,entry9):
    f =open("program/assets/popup.json", "r+")
    jsonData = json.load(f)
    jsonData["text"] = entry1.get(1.0, tkinter.END)
    jsonData["textS"]=float(entry7.get())
    jsonData["color"] = entry2[1]
    jsonData["textColor"] = entry4[1]
    jsonData["duration"] = float(entry3.get())
    jsonData["opacity"] = float(entry5.get())
    jsonData["borderR"] = float(entry6.get())
    jsonData["in"] = entry8.get()
    jsonData["out"] = entry9.get()
    f.seek(0)
    f.write(json.dumps(jsonData))
    f.truncate()
    f.close()
def setDefault(entry, tag):
    f = open("program/assets/default.json", "r+")
    jsonData = json.load(f)
    jsonData[tag] = entry.get()
    f.seek(0)
    f.write(json.dumps(jsonData))
    f.truncate()
    f.close()
def colorDefault(page):
    f = open("program/assets/default.json", "r+")
    jsonData=json.load(f)
    jsonData["bg"] = page.color[1]
    jsonData["tc"] = page.textColor[1]
    f.seek(0)
    f.write(json.dumps(jsonData))
    f.truncate()
    f.close()
class window:
    def __init__(self):
        self.root = tkinter.Tk()
        self.root.iconbitmap("program/assets/favicon.ico", )
        self.__makebuttons__()
        self.root.mainloop()
        
    def __makebuttons__(self):
        f = open("program/assets/default.json", "r")
        jsonData = json.load(f)
        f.close()
        self.label1 = tkinter.Label(self.root, text="text to go into the popup"
                                    ).grid(row=0, column=0, sticky=tkinter.NW)
        
        self.button1 = tkinter.Text(self.root, width=27, height=2.5)
        self.button1.grid(row=0, column=1, columnspan=2)
        
        self.label2 = tkinter.Label(self.root, text="text size(decimal number"+
       " 1.0-10.0)").grid(row=1, column=0, sticky=tkinter.W)
        
        self.ts = tkinter.Entry(self.root, width=25)
        self.ts.grid(row=1, column=1, sticky=tkinter.W)
        self.ts.insert(0, jsonData["ts"])
        
        self.tsDefault = tkinter.Button(self.root, text="set default", command=
                                        lambda:setDefault(self.ts, "ts"))
        self.tsDefault.grid(row=1, column=2)
        
        self.label3 = tkinter.Label(self.root, text="how long the popup will "+
        "stay up, in seconds").grid(row=2, column=0, sticky=tkinter.W)
        
        self.duration = tkinter.Entry(self.root, width=25)
        self.duration.grid(row=2, column=1, sticky=tkinter.W)
        self.duration.insert(0, jsonData["duration"])
        
        self.durationDefault = tkinter.Button(self.root, text="set default", 
                                              command=
                                              lambda:setDefault(self.duration, 
                                                                "duration"))
        self.durationDefault.grid(row=2, column=2)
        
        self.label4 = tkinter.Label(self.root, text="the opacity of the popup"
                                    ).grid(row=3, column=0, sticky=tkinter.W)
        
        self.opacity = tkinter.Entry(self.root, width=25)
        self.opacity.grid(row=3, column=1, sticky=tkinter.W)
        self.opacity.insert(0, jsonData["opacity"])
        
        self.opacityDefault = tkinter.Button(self.root, text="set default", 
                                             command=
                                             lambda:setDefault(self.opacity, 
                                                               "opacity"))
        self.opacityDefault.grid(row=3, column=2)
        
        self.label5 = tkinter.Label(self.root, text="how curved the popup "+
        "corners are(border radius)").grid(row=4, column=0, sticky=tkinter.W)
        
        self.borderR = tkinter.Entry(self.root, width=25)
        self.borderR.grid(row=4, column=1, sticky=tkinter.W)
        self.borderR.insert(0, jsonData["borderR"])
        
        self.borderRDefault = tkinter.Button(self.root, text="set default", 
                                             command=
                                             lambda:setDefault(self.borderR,
                                                                "borderR"))
        self.borderRDefault.grid(row=4, column=2)
        
        self.label6 = tkinter.Label(self.root, text="will come in from"
                                    ).grid(row=5, column=0, sticky=tkinter.W)
        
        self.inFrom = tkinter.StringVar()
        self.inFrom.set(jsonData["in"])
        self.inFromB = tkinter.OptionMenu(self.root, self.inFrom, "left", 
                                          "top", "bottom")
        self.inFromB.grid(row=5, column=1, sticky=tkinter.W)
        
        self.inFromDefault = tkinter.Button(self.root, text="set default", 
                                            command=
                                            lambda:setDefault(self.inFrom,"in")
                                            )
        self.inFromDefault.grid(row=5, column=2)
        
        self.label6 = tkinter.Label(self.root, text="will leave from"
                                    ).grid(row=6, column=0, sticky=tkinter.W)
        
        self.outFrom = tkinter.StringVar()
        self.outFrom.set(jsonData["out"])
        self.outFromB = tkinter.OptionMenu(self.root, self.outFrom, "left", 
                                           "top", "bottom")
        self.outFromB.grid(row=6, column=1, sticky=tkinter.W)
        
        self.outFromDefault = tkinter.Button(self.root, text="set default", 
                                             command=
                                             lambda:setDefault(self.outFrom, 
                                                               "out"))
        self.outFromDefault.grid(row=6, column=2)
        
        self.color = ((0, 0, 0), jsonData["bg"])
        self.colorVar = tkinter.StringVar()
        self.colorVar.set("background color: "+self.color[1])
        self.bg = tkinter.Button(self.root, textvariable=self.colorVar, 
                                 command=self.__colorset__)
        self.bg.grid(row=7, column=0, sticky=tkinter.E)
        
        self.textColor = ((0, 0, 0), jsonData["tc"])
        self.textColorVar = tkinter.StringVar()
        self.textColorVar.set("text color: "+self.textColor[1])
        self.tc = tkinter.Button(self.root, textvariable=self.textColorVar, 
                                 command=self.__textcolorset__)
        self.tc.grid(row=7, column=1, sticky=tkinter.W)
        
        self.colorDefault = tkinter.Button(self.root, text="set default", 
                                           command=lambda:colorDefault(self))
        self.colorDefault.grid(row=7, column=2)
        
        self.reset = tkinter.Button(self.root, text="reset defaults", width=10, 
                                 command=reset)
        self.reset.grid(row=8, column=1, sticky=tkinter.E)
        
        self.go = tkinter.Button(self.root, text="go", width=8, 
                                 command=lambda: popup(self))
        self.go.grid(row=8, column=2, sticky=tkinter.W)
    def __colorset__(self):
        x = askcolor()
        try:
            y = x[1] + ""
        except TypeError:
            x = self.color
        self.color=x
        self.colorVar.set("background color: "+self.color[1])
    def __textcolorset__(self):
        x = askcolor()
        try:
            y = x[1] + ""
        except TypeError:
            x = self.textColor
        self.textColor=x
        self.textColorVar.set("text color: "+self.textColor[1])
        print self.textColor[1]
    def showwarning(self, mess):
        tkMessageBox.showerror("alert", mess)
main = window()    

