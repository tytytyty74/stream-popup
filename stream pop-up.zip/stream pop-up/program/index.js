
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var fs = require("fs");
var spawn = require("child_process").spawn;
var port = process.env.PORT || 3000;

var program = spawn("python", ["program/main.py"])
app.get('/', function(req, res){
    res.sendFile(__dirname + '/popup.html');
});

fs.watchFile("assets/popup.json", {interval:100}, function(curr, prev)
{
    fs.readFile("assets/popup.json",{encoding:"utf8"}, function(err, data){
        io.emit("popup", data);
    });
});
http.listen(port, function(){
  console.log("working");
  console.log('listening on *:' + port);
});
